Py Packager use PyInstaller built into a PyQt6 GUI to simplify packaging Python builds into a single .exe file.
This is by no means a comprehensive Python compiler and may need to be modified for specific requirements.
